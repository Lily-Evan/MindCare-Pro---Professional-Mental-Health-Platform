async function handler({
  taskDescription,
  userContext = {},
  existingTasks = [],
}) {
  if (!taskDescription || typeof taskDescription !== "string") {
    return {
      error: "Task description is required and must be a string",
      success: false,
    };
  }

  try {
    const systemPrompt = `You are an AI task creation assistant. Your job is to parse natural language input and create structured task data.

Analyze the user's input and extract:
1. Main task title (clear, actionable)
2. Priority level (high, medium, low)
3. Category (work, personal, health, learning, etc.)
4. Due date (if mentioned or can be inferred)
5. Estimated duration
6. Subtasks (break down complex tasks)
7. Tags/labels
8. Dependencies on existing tasks

User Context:
- Current date: ${new Date().toISOString().split("T")[0]}
- User timezone: ${userContext.timezone || "UTC"}
- Work schedule: ${userContext.workSchedule || "Standard business hours"}
- Existing tasks count: ${existingTasks.length}

Return response in this exact JSON structure:
{
  "task": {
    "title": "clear, actionable task title",
    "description": "detailed description",
    "priority": "high|medium|low",
    "category": "category name",
    "dueDate": "YYYY-MM-DD or null",
    "estimatedDuration": "time estimate in minutes",
    "status": "pending",
    "tags": ["tag1", "tag2"],
    "subtasks": [
      {
        "title": "subtask title",
        "completed": false,
        "estimatedDuration": "minutes"
      }
    ]
  },
  "suggestions": {
    "relatedTasks": ["suggestion1", "suggestion2"],
    "improvements": ["improvement1", "improvement2"],
    "scheduling": "best time to work on this task"
  },
  "analysis": {
    "complexity": "simple|moderate|complex",
    "urgency": "immediate|soon|flexible",
    "dependencies": ["existing task titles that this depends on"]
  }
}

Be smart about inferring context. For example:
- "Call mom tomorrow" → due date is tomorrow, category is personal
- "Finish the quarterly report by Friday" → work category, high priority, due Friday
- "Learn Spanish" → learning category, break into subtasks, no specific due date
- "Buy groceries milk bread eggs" → personal category, create subtasks for each item`;

    const existingTasksContext =
      existingTasks.length > 0
        ? `\n\nExisting tasks for reference:\n${existingTasks
            .map((task) => `- ${task.title || task}`)
            .join("\n")}`
        : "";

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_CLAUDE_SONNET_3_5,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-3-5-sonnet-20241022",
        max_tokens: 1500,
        messages: [
          {
            role: "user",
            content: `Parse this task request: "${taskDescription}"${existingTasksContext}`,
          },
        ],
        system: systemPrompt,
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(`Claude API error: ${response.status} - ${errorData}`);
    }

    const data = await response.json();

    if (
      !data.content ||
      !Array.isArray(data.content) ||
      data.content.length === 0
    ) {
      throw new Error("Invalid response format from Claude API");
    }

    const aiResponse = data.content[0].text;

    let taskData;
    try {
      const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        taskData = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("No JSON found in AI response");
      }
    } catch (parseError) {
      taskData = createFallbackTask(taskDescription);
    }

    if (!taskData.task) {
      taskData = { task: taskData, suggestions: {}, analysis: {} };
    }

    taskData.task.id = generateTaskId();
    taskData.task.createdAt = new Date().toISOString();
    taskData.task.updatedAt = new Date().toISOString();

    if (taskData.task.subtasks && Array.isArray(taskData.task.subtasks)) {
      taskData.task.subtasks = taskData.task.subtasks.map((subtask) => ({
        ...subtask,
        id: generateTaskId(),
        completed: false,
      }));
    }

    return {
      success: true,
      task: taskData.task,
      suggestions: taskData.suggestions || {},
      analysis: taskData.analysis || {},
      originalInput: taskDescription,
      processingTime: Date.now(),
      aiConfidence: calculateConfidence(taskDescription, taskData),
      metadata: {
        model: "claude-3-5-sonnet",
        timestamp: new Date().toISOString(),
        userContext: userContext,
      },
    };
  } catch (error) {
    console.error("Task creation error:", error);

    const fallbackTask = createFallbackTask(taskDescription);

    return {
      error: "AI processing failed, created basic task structure",
      success: false,
      task: fallbackTask,
      fallback: true,
      originalInput: taskDescription,
      errorType: error.message.includes("API")
        ? "api_error"
        : "processing_error",
      timestamp: new Date().toISOString(),
    };
  }
}

function createFallbackTask(description) {
  const words = description.toLowerCase();

  let priority = "medium";
  if (
    words.includes("urgent") ||
    words.includes("asap") ||
    words.includes("immediately")
  ) {
    priority = "high";
  } else if (
    words.includes("later") ||
    words.includes("someday") ||
    words.includes("eventually")
  ) {
    priority = "low";
  }

  let category = "personal";
  if (
    words.includes("work") ||
    words.includes("meeting") ||
    words.includes("report") ||
    words.includes("project")
  ) {
    category = "work";
  } else if (
    words.includes("exercise") ||
    words.includes("health") ||
    words.includes("doctor")
  ) {
    category = "health";
  } else if (
    words.includes("learn") ||
    words.includes("study") ||
    words.includes("course")
  ) {
    category = "learning";
  }

  return {
    id: generateTaskId(),
    title:
      description.length > 50
        ? description.substring(0, 50) + "..."
        : description,
    description: description,
    priority: priority,
    category: category,
    dueDate: null,
    estimatedDuration: 30,
    status: "pending",
    tags: [],
    subtasks: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

function generateTaskId() {
  return "task_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
}

function calculateConfidence(input, taskData) {
  let confidence = 0.5;

  if (taskData.task && taskData.task.title && taskData.task.title.length > 0) {
    confidence += 0.2;
  }

  if (
    taskData.task &&
    taskData.task.category &&
    taskData.task.category !== "general"
  ) {
    confidence += 0.1;
  }

  if (taskData.task && taskData.task.dueDate) {
    confidence += 0.1;
  }

  if (
    taskData.task &&
    taskData.task.subtasks &&
    taskData.task.subtasks.length > 0
  ) {
    confidence += 0.1;
  }

  return Math.min(confidence, 1.0);
}
export async function POST(request) {
  return handler(await request.json());
}