async function handler({
  biometricData,
  deviceType,
  timeRange,
  userProfile,
  historicalData,
}) {
  if (!biometricData || typeof biometricData !== "object") {
    return {
      error: "Biometric data is required and must be an object",
      success: false,
    };
  }

  try {
    const processedData = processBiometricData(biometricData, deviceType);

    const stressAnalysis = await analyzeStressPatterns(
      processedData,
      historicalData,
      userProfile
    );

    const realTimeStress = calculateRealTimeStressLevel(processedData);

    const anomalies = detectStressAnomalies(processedData, historicalData);

    const sleepImpact = analyzeSleepStressCorrelation(processedData);

    const hrvAnalysis = analyzeHeartRateVariability(processedData);

    const burnoutRisk = assessBurnoutRisk(
      stressAnalysis,
      processedData,
      userProfile
    );

    const recommendations = await generatePersonalizedRecommendations(
      stressAnalysis,
      realTimeStress,
      userProfile,
      burnoutRisk
    );

    const wellnessReport = generateWellnessReport({
      stressAnalysis,
      realTimeStress,
      anomalies,
      sleepImpact,
      hrvAnalysis,
      burnoutRisk,
      recommendations,
      timeRange,
      userProfile,
    });

    return {
      success: true,
      timestamp: new Date().toISOString(),
      deviceType: deviceType,
      timeRange: timeRange,
      realTimeStress: realTimeStress,
      stressAnalysis: stressAnalysis,
      anomalies: anomalies,
      sleepImpact: sleepImpact,
      hrvAnalysis: hrvAnalysis,
      burnoutRisk: burnoutRisk,
      recommendations: recommendations,
      wellnessReport: wellnessReport,
      alerts: generateAlerts(realTimeStress, anomalies, burnoutRisk),
      metadata: {
        processingTime: Date.now(),
        dataPoints: processedData.totalDataPoints,
        analysisConfidence: calculateAnalysisConfidence(
          processedData,
          historicalData
        ),
      },
    };
  } catch (error) {
    console.error("Wearables stress monitoring error:", error);
    return {
      error: "Failed to process biometric data: " + error.message,
      success: false,
      timestamp: new Date().toISOString(),
      fallbackData: generateFallbackAnalysis(biometricData, deviceType),
    };
  }
}

function processBiometricData(data, deviceType) {
  const processed = {
    heartRate: [],
    heartRateVariability: [],
    sleepData: {},
    activityLevel: [],
    skinTemperature: [],
    bloodOxygen: [],
    stressIndicators: [],
    timestamp: [],
    totalDataPoints: 0,
  };

  if (data.heartRate && Array.isArray(data.heartRate)) {
    processed.heartRate = data.heartRate.map((hr) => ({
      value: hr.value || hr,
      timestamp: hr.timestamp || new Date().toISOString(),
      quality: hr.quality || "good",
    }));
  }

  if (data.hrv && Array.isArray(data.hrv)) {
    processed.heartRateVariability = data.hrv.map((hrv) => ({
      rmssd: hrv.rmssd || hrv.value || hrv,
      timestamp: hrv.timestamp || new Date().toISOString(),
      quality: hrv.quality || "good",
    }));
  }

  if (data.sleep) {
    processed.sleepData = {
      duration: data.sleep.duration || 0,
      quality: data.sleep.quality || "unknown",
      deepSleep: data.sleep.deepSleep || 0,
      remSleep: data.sleep.remSleep || 0,
      lightSleep: data.sleep.lightSleep || 0,
      awakenings: data.sleep.awakenings || 0,
      sleepEfficiency: data.sleep.efficiency || 0,
      bedtime: data.sleep.bedtime,
      wakeTime: data.sleep.wakeTime,
    };
  }

  if (data.activity && Array.isArray(data.activity)) {
    processed.activityLevel = data.activity.map((act) => ({
      steps: act.steps || 0,
      calories: act.calories || 0,
      intensity: act.intensity || "low",
      timestamp: act.timestamp || new Date().toISOString(),
    }));
  }

  if (data.temperature && Array.isArray(data.temperature)) {
    processed.skinTemperature = data.temperature.map((temp) => ({
      value: temp.value || temp,
      timestamp: temp.timestamp || new Date().toISOString(),
    }));
  }

  if (data.bloodOxygen && Array.isArray(data.bloodOxygen)) {
    processed.bloodOxygen = data.bloodOxygen.map((spo2) => ({
      value: spo2.value || spo2,
      timestamp: spo2.timestamp || new Date().toISOString(),
    }));
  }

  processed.totalDataPoints =
    processed.heartRate.length +
    processed.heartRateVariability.length +
    processed.activityLevel.length +
    processed.skinTemperature.length +
    processed.bloodOxygen.length;

  return processed;
}

async function analyzeStressPatterns(
  processedData,
  historicalData,
  userProfile
) {
  const systemPrompt = `You are an expert biometric data analyst specializing in stress pattern recognition. Analyze the provided biometric data to identify stress patterns, trends, and correlations.

Focus on:
1. Heart rate patterns and stress correlation
2. Heart rate variability trends
3. Sleep quality impact on stress levels
4. Activity patterns and stress relationship
5. Circadian rhythm disruptions
6. Stress accumulation patterns
7. Recovery periods identification
8. Chronic vs acute stress indicators

Return analysis in this JSON structure:
{
  "overallStressLevel": "low|moderate|high|severe",
  "stressTrends": {
    "direction": "improving|stable|worsening",
    "confidence": 0.0-1.0,
    "timeframe": "hours|days|weeks"
  },
  "patterns": {
    "dailyPattern": "morning_high|afternoon_peak|evening_elevated|night_disrupted",
    "weeklyPattern": "weekday_stress|weekend_recovery|consistent",
    "triggers": ["work_hours", "poor_sleep", "high_activity", "low_activity"]
  },
  "correlations": {
    "sleepStressCorr": -1.0-1.0,
    "activityStressCorr": -1.0-1.0,
    "hrvStressCorr": -1.0-1.0
  },
  "riskFactors": ["chronic_elevation", "poor_recovery", "sleep_disruption", "hrv_decline"],
  "insights": ["insight1", "insight2", "insight3"]
}`;

  try {
    const response = await fetch("/integrations/anthropic-claude-sonnet-3-5/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages: [
          {
            role: "user",
            content: `Analyze this biometric data for stress patterns:

Current Data:
- Heart Rate: ${JSON.stringify(processedData.heartRate.slice(-20))}
- HRV: ${JSON.stringify(processedData.heartRateVariability.slice(-20))}
- Sleep: ${JSON.stringify(processedData.sleepData)}
- Activity: ${JSON.stringify(processedData.activityLevel.slice(-10))}

Historical Context:
${
  historicalData
    ? JSON.stringify(historicalData)
    : "No historical data available"
}

User Profile:
- Age: ${userProfile?.age || "unknown"}
- Gender: ${userProfile?.gender || "unknown"}
- Fitness Level: ${userProfile?.fitnessLevel || "unknown"}
- Health Conditions: ${userProfile?.healthConditions || "none reported"}
- Stress History: ${userProfile?.stressHistory || "unknown"}`,
          },
        ],
        json_schema: {
          name: "stress_pattern_analysis",
          schema: {
            type: "object",
            properties: {
              overallStressLevel: { type: "string" },
              stressTrends: {
                type: "object",
                properties: {
                  direction: { type: "string" },
                  confidence: { type: "number" },
                  timeframe: { type: "string" },
                },
                required: ["direction", "confidence", "timeframe"],
                additionalProperties: false,
              },
              patterns: {
                type: "object",
                properties: {
                  dailyPattern: { type: "string" },
                  weeklyPattern: { type: "string" },
                  triggers: {
                    type: "array",
                    items: { type: "string" },
                  },
                },
                required: ["dailyPattern", "weeklyPattern", "triggers"],
                additionalProperties: false,
              },
              correlations: {
                type: "object",
                properties: {
                  sleepStressCorr: { type: "number" },
                  activityStressCorr: { type: "number" },
                  hrvStressCorr: { type: "number" },
                },
                required: [
                  "sleepStressCorr",
                  "activityStressCorr",
                  "hrvStressCorr",
                ],
                additionalProperties: false,
              },
              riskFactors: {
                type: "array",
                items: { type: "string" },
              },
              insights: {
                type: "array",
                items: { type: "string" },
              },
            },
            required: [
              "overallStressLevel",
              "stressTrends",
              "patterns",
              "correlations",
              "riskFactors",
              "insights",
            ],
            additionalProperties: false,
          },
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Analysis API error: ${response.status}`);
    }

    const data = await response.json();
    return JSON.parse(data.choices[0].message.content);
  } catch (error) {
    console.error("Stress pattern analysis error:", error);
    return generateFallbackStressAnalysis(processedData);
  }
}

function calculateRealTimeStressLevel(processedData) {
  const currentTime = new Date();
  const recentWindow = 15 * 60 * 1000;

  const recentHR = processedData.heartRate.filter(
    (hr) => new Date(hr.timestamp) > new Date(currentTime - recentWindow)
  );

  const recentHRV = processedData.heartRateVariability.filter(
    (hrv) => new Date(hrv.timestamp) > new Date(currentTime - recentWindow)
  );

  let stressScore = 0;
  let confidence = 0;

  if (recentHR.length > 0) {
    const avgHR =
      recentHR.reduce((sum, hr) => sum + hr.value, 0) / recentHR.length;
    const restingHR = 60;
    const hrStress = Math.max(0, (avgHR - restingHR) / 40);
    stressScore += hrStress * 0.4;
    confidence += 0.3;
  }

  if (recentHRV.length > 0) {
    const avgHRV =
      recentHRV.reduce((sum, hrv) => sum + hrv.rmssd, 0) / recentHRV.length;
    const normalHRV = 40;
    const hrvStress = Math.max(0, (normalHRV - avgHRV) / normalHRV);
    stressScore += hrvStress * 0.6;
    confidence += 0.4;
  }

  const level =
    stressScore < 0.3
      ? "low"
      : stressScore < 0.6
      ? "moderate"
      : stressScore < 0.8
      ? "high"
      : "severe";

  return {
    level: level,
    score: Math.min(stressScore, 1.0),
    confidence: Math.min(confidence, 1.0),
    timestamp: currentTime.toISOString(),
    dataPoints: recentHR.length + recentHRV.length,
    factors: {
      heartRate:
        recentHR.length > 0 ? recentHR[recentHR.length - 1].value : null,
      hrv: recentHRV.length > 0 ? recentHRV[recentHRV.length - 1].rmssd : null,
    },
  };
}

function detectStressAnomalies(processedData, historicalData) {
  const anomalies = [];

  if (processedData.heartRate.length > 0) {
    const hrValues = processedData.heartRate.map((hr) => hr.value);
    const hrMean = hrValues.reduce((a, b) => a + b, 0) / hrValues.length;
    const hrStd = Math.sqrt(
      hrValues.reduce((sq, n) => sq + Math.pow(n - hrMean, 2), 0) /
        hrValues.length
    );

    processedData.heartRate.forEach((hr) => {
      if (Math.abs(hr.value - hrMean) > 2 * hrStd) {
        anomalies.push({
          type: "heart_rate_spike",
          severity: hr.value > hrMean + 2 * hrStd ? "high" : "moderate",
          value: hr.value,
          timestamp: hr.timestamp,
          description: `Heart rate ${
            hr.value > hrMean ? "spike" : "drop"
          } detected: ${hr.value} bpm`,
        });
      }
    });
  }

  if (processedData.heartRateVariability.length > 0) {
    const hrvValues = processedData.heartRateVariability.map(
      (hrv) => hrv.rmssd
    );
    const hrvMean = hrvValues.reduce((a, b) => a + b, 0) / hrvValues.length;

    processedData.heartRateVariability.forEach((hrv) => {
      if (hrv.rmssd < hrvMean * 0.5) {
        anomalies.push({
          type: "hrv_suppression",
          severity: hrv.rmssd < hrvMean * 0.3 ? "high" : "moderate",
          value: hrv.rmssd,
          timestamp: hrv.timestamp,
          description: `Significant HRV suppression detected: ${hrv.rmssd}ms`,
        });
      }
    });
  }

  return {
    count: anomalies.length,
    anomalies: anomalies,
    riskLevel:
      anomalies.length > 5 ? "high" : anomalies.length > 2 ? "moderate" : "low",
  };
}

function analyzeSleepStressCorrelation(processedData) {
  const sleepData = processedData.sleepData;

  if (!sleepData.duration) {
    return {
      correlation: null,
      impact: "unknown",
      recommendations: ["Ensure sleep tracking is enabled on your device"],
    };
  }

  const sleepQualityScore = calculateSleepQualityScore(sleepData);
  const stressImpact =
    sleepQualityScore < 0.6
      ? "high"
      : sleepQualityScore < 0.8
      ? "moderate"
      : "low";

  return {
    sleepQuality: sleepQualityScore,
    duration: sleepData.duration,
    efficiency: sleepData.sleepEfficiency,
    stressImpact: stressImpact,
    insights: [
      sleepData.duration < 7
        ? "Sleep duration below recommended 7-9 hours"
        : "Sleep duration adequate",
      sleepData.sleepEfficiency < 0.85
        ? "Sleep efficiency could be improved"
        : "Good sleep efficiency",
      sleepData.awakenings > 3
        ? "Frequent sleep disruptions detected"
        : "Sleep continuity good",
    ],
    recommendations: generateSleepRecommendations(sleepData, stressImpact),
  };
}

function analyzeHeartRateVariability(processedData) {
  if (processedData.heartRateVariability.length === 0) {
    return {
      status: "no_data",
      message: "No HRV data available for analysis",
    };
  }

  const hrvValues = processedData.heartRateVariability.map((hrv) => hrv.rmssd);
  const avgHRV = hrvValues.reduce((a, b) => a + b, 0) / hrvValues.length;
  const minHRV = Math.min(...hrvValues);
  const maxHRV = Math.max(...hrvValues);

  const hrvStatus =
    avgHRV > 40
      ? "excellent"
      : avgHRV > 30
      ? "good"
      : avgHRV > 20
      ? "fair"
      : "poor";

  const trend = calculateHRVTrend(processedData.heartRateVariability);

  return {
    average: avgHRV,
    range: { min: minHRV, max: maxHRV },
    status: hrvStatus,
    trend: trend,
    autonomicBalance: avgHRV > 35 ? "balanced" : "sympathetic_dominant",
    stressResilience: avgHRV > 40 ? "high" : avgHRV > 25 ? "moderate" : "low",
    recommendations: generateHRVRecommendations(avgHRV, hrvStatus, trend),
  };
}

function assessBurnoutRisk(stressAnalysis, processedData, userProfile) {
  let riskScore = 0;
  const riskFactors = [];

  if (
    stressAnalysis.overallStressLevel === "high" ||
    stressAnalysis.overallStressLevel === "severe"
  ) {
    riskScore += 0.3;
    riskFactors.push("chronic_high_stress");
  }

  if (stressAnalysis.stressTrends.direction === "worsening") {
    riskScore += 0.2;
    riskFactors.push("worsening_stress_trend");
  }

  if (stressAnalysis.riskFactors.includes("poor_recovery")) {
    riskScore += 0.2;
    riskFactors.push("inadequate_recovery");
  }

  if (
    processedData.sleepData.duration &&
    processedData.sleepData.duration < 6
  ) {
    riskScore += 0.15;
    riskFactors.push("chronic_sleep_deprivation");
  }

  const hrvData = processedData.heartRateVariability;
  if (hrvData.length > 0) {
    const avgHRV =
      hrvData.reduce((sum, hrv) => sum + hrv.rmssd, 0) / hrvData.length;
    if (avgHRV < 20) {
      riskScore += 0.15;
      riskFactors.push("severely_suppressed_hrv");
    }
  }

  const riskLevel =
    riskScore < 0.3
      ? "low"
      : riskScore < 0.6
      ? "moderate"
      : riskScore < 0.8
      ? "high"
      : "critical";

  return {
    riskLevel: riskLevel,
    riskScore: Math.min(riskScore, 1.0),
    riskFactors: riskFactors,
    earlyWarnings: generateEarlyWarnings(riskLevel, riskFactors),
    interventionRecommendations: generateInterventionRecommendations(
      riskLevel,
      riskFactors
    ),
    monitoringFrequency:
      riskLevel === "critical"
        ? "hourly"
        : riskLevel === "high"
        ? "every_4_hours"
        : riskLevel === "moderate"
        ? "twice_daily"
        : "daily",
  };
}

async function generatePersonalizedRecommendations(
  stressAnalysis,
  realTimeStress,
  userProfile,
  burnoutRisk
) {
  const systemPrompt = `You are a wellness expert providing personalized stress management recommendations based on biometric data analysis.

Generate specific, actionable recommendations considering:
1. Current stress level and patterns
2. User profile and preferences
3. Burnout risk assessment
4. Evidence-based stress management techniques
5. Lifestyle modifications
6. Professional intervention needs

Return recommendations in this JSON structure:
{
  "immediate": ["action1", "action2"],
  "shortTerm": ["goal1", "goal2"],
  "longTerm": ["strategy1", "strategy2"],
  "lifestyle": {
    "sleep": ["sleep_tip1", "sleep_tip2"],
    "exercise": ["exercise_tip1", "exercise_tip2"],
    "nutrition": ["nutrition_tip1", "nutrition_tip2"],
    "mindfulness": ["mindfulness_tip1", "mindfulness_tip2"]
  },
  "professional": {
    "recommended": true/false,
    "urgency": "low|moderate|high|urgent",
    "specialists": ["specialist1", "specialist2"]
  },
  "monitoring": ["metric1", "metric2"],
  "alerts": ["alert_condition1", "alert_condition2"]
}`;

  try {
    const response = await fetch("/integrations/anthropic-claude-sonnet-3-5/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages: [
          {
            role: "user",
            content: `Generate personalized stress management recommendations:

Current Stress Analysis:
${JSON.stringify(stressAnalysis)}

Real-time Stress Level:
${JSON.stringify(realTimeStress)}

User Profile:
${JSON.stringify(userProfile)}

Burnout Risk Assessment:
${JSON.stringify(burnoutRisk)}`,
          },
        ],
        json_schema: {
          name: "stress_recommendations",
          schema: {
            type: "object",
            properties: {
              immediate: {
                type: "array",
                items: { type: "string" },
              },
              shortTerm: {
                type: "array",
                items: { type: "string" },
              },
              longTerm: {
                type: "array",
                items: { type: "string" },
              },
              lifestyle: {
                type: "object",
                properties: {
                  sleep: {
                    type: "array",
                    items: { type: "string" },
                  },
                  exercise: {
                    type: "array",
                    items: { type: "string" },
                  },
                  nutrition: {
                    type: "array",
                    items: { type: "string" },
                  },
                  mindfulness: {
                    type: "array",
                    items: { type: "string" },
                  },
                },
                required: ["sleep", "exercise", "nutrition", "mindfulness"],
                additionalProperties: false,
              },
              professional: {
                type: "object",
                properties: {
                  recommended: { type: "boolean" },
                  urgency: { type: "string" },
                  specialists: {
                    type: "array",
                    items: { type: "string" },
                  },
                },
                required: ["recommended", "urgency", "specialists"],
                additionalProperties: false,
              },
              monitoring: {
                type: "array",
                items: { type: "string" },
              },
              alerts: {
                type: "array",
                items: { type: "string" },
              },
            },
            required: [
              "immediate",
              "shortTerm",
              "longTerm",
              "lifestyle",
              "professional",
              "monitoring",
              "alerts",
            ],
            additionalProperties: false,
          },
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Recommendations API error: ${response.status}`);
    }

    const data = await response.json();
    return JSON.parse(data.choices[0].message.content);
  } catch (error) {
    console.error("Recommendations generation error:", error);
    return generateFallbackRecommendations(
      stressAnalysis,
      realTimeStress,
      burnoutRisk
    );
  }
}

function generateWellnessReport(data) {
  const report = {
    reportId: `wellness_${Date.now()}`,
    generatedAt: new Date().toISOString(),
    timeRange: data.timeRange,
    summary: {
      overallWellness: calculateOverallWellness(data),
      keyFindings: extractKeyFindings(data),
      riskLevel: data.burnoutRisk.riskLevel,
      recommendationsPriority:
        data.burnoutRisk.riskLevel === "critical"
          ? "urgent"
          : data.burnoutRisk.riskLevel === "high"
          ? "high"
          : "moderate",
    },
    metrics: {
      stressLevel: data.realTimeStress.level,
      stressScore: data.realTimeStress.score,
      hrvStatus: data.hrvAnalysis.status,
      sleepQuality: data.sleepImpact.sleepQuality,
      anomaliesDetected: data.anomalies.count,
    },
    trends: {
      stressDirection: data.stressAnalysis.stressTrends.direction,
      stressConfidence: data.stressAnalysis.stressTrends.confidence,
      patterns: data.stressAnalysis.patterns,
    },
    actionItems: {
      immediate: data.recommendations.immediate,
      shortTerm: data.recommendations.shortTerm,
      longTerm: data.recommendations.longTerm,
    },
    professionalGuidance: data.recommendations.professional,
    nextReviewDate: calculateNextReviewDate(data.burnoutRisk.riskLevel),
  };

  return report;
}

function generateAlerts(realTimeStress, anomalies, burnoutRisk) {
  const alerts = [];

  if (realTimeStress.level === "severe") {
    alerts.push({
      type: "critical_stress",
      severity: "high",
      message:
        "Critical stress level detected. Consider immediate stress reduction techniques.",
      timestamp: new Date().toISOString(),
      action: "Take a 10-minute break and practice deep breathing",
    });
  }

  if (anomalies.riskLevel === "high") {
    alerts.push({
      type: "biometric_anomaly",
      severity: "moderate",
      message: `${anomalies.count} biometric anomalies detected in recent data.`,
      timestamp: new Date().toISOString(),
      action: "Monitor closely and consider consulting healthcare provider",
    });
  }

  if (burnoutRisk.riskLevel === "critical") {
    alerts.push({
      type: "burnout_warning",
      severity: "critical",
      message:
        "Critical burnout risk detected. Professional intervention recommended.",
      timestamp: new Date().toISOString(),
      action:
        "Schedule appointment with healthcare provider or mental health professional",
    });
  }

  return alerts;
}

function calculateAnalysisConfidence(processedData, historicalData) {
  let confidence = 0;

  if (processedData.heartRate.length > 10) confidence += 0.3;
  if (processedData.heartRateVariability.length > 5) confidence += 0.3;
  if (processedData.sleepData.duration) confidence += 0.2;
  if (historicalData && Object.keys(historicalData).length > 0)
    confidence += 0.2;

  return Math.min(confidence, 1.0);
}

function generateFallbackAnalysis(biometricData, deviceType) {
  return {
    message: "Limited analysis available due to processing error",
    basicMetrics: {
      dataReceived: !!biometricData,
      deviceType: deviceType || "unknown",
      timestamp: new Date().toISOString(),
    },
    recommendations: [
      "Ensure device is properly connected and synced",
      "Check data quality and completeness",
      "Try again in a few minutes",
    ],
  };
}

function generateFallbackStressAnalysis(processedData) {
  return {
    overallStressLevel: "moderate",
    stressTrends: {
      direction: "stable",
      confidence: 0.3,
      timeframe: "hours",
    },
    patterns: {
      dailyPattern: "consistent",
      weeklyPattern: "stable",
      triggers: ["data_insufficient"],
    },
    correlations: {
      sleepStressCorr: 0,
      activityStressCorr: 0,
      hrvStressCorr: 0,
    },
    riskFactors: ["insufficient_data"],
    insights: ["More data needed for comprehensive analysis"],
  };
}

function calculateSleepQualityScore(sleepData) {
  let score = 0;

  if (sleepData.duration >= 7 && sleepData.duration <= 9) score += 0.3;
  else if (sleepData.duration >= 6) score += 0.2;

  if (sleepData.sleepEfficiency >= 0.85) score += 0.3;
  else if (sleepData.sleepEfficiency >= 0.75) score += 0.2;

  if (sleepData.awakenings <= 2) score += 0.2;
  else if (sleepData.awakenings <= 4) score += 0.1;

  if (sleepData.deepSleep >= 0.15) score += 0.2;
  else if (sleepData.deepSleep >= 0.1) score += 0.1;

  return Math.min(score, 1.0);
}

function generateSleepRecommendations(sleepData, stressImpact) {
  const recommendations = [];

  if (sleepData.duration < 7) {
    recommendations.push("Aim for 7-9 hours of sleep per night");
  }

  if (sleepData.sleepEfficiency < 0.85) {
    recommendations.push(
      "Improve sleep environment (temperature, darkness, quiet)"
    );
  }

  if (sleepData.awakenings > 3) {
    recommendations.push(
      "Consider sleep hygiene practices to reduce nighttime awakenings"
    );
  }

  if (stressImpact === "high") {
    recommendations.push("Prioritize stress reduction before bedtime");
    recommendations.push(
      "Consider relaxation techniques like meditation or reading"
    );
  }

  return recommendations;
}

function calculateHRVTrend(hrvData) {
  if (hrvData.length < 3) return "insufficient_data";

  const recent = hrvData.slice(-3).map((hrv) => hrv.rmssd);
  const earlier = hrvData.slice(-6, -3).map((hrv) => hrv.rmssd);

  if (earlier.length === 0) return "insufficient_data";

  const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
  const earlierAvg = earlier.reduce((a, b) => a + b, 0) / earlier.length;

  const change = (recentAvg - earlierAvg) / earlierAvg;

  if (change > 0.1) return "improving";
  if (change < -0.1) return "declining";
  return "stable";
}

function generateHRVRecommendations(avgHRV, status, trend) {
  const recommendations = [];

  if (status === "poor") {
    recommendations.push("Focus on stress reduction and recovery practices");
    recommendations.push("Ensure adequate sleep and avoid overtraining");
  }

  if (trend === "declining") {
    recommendations.push(
      "Monitor for signs of overreaching or excessive stress"
    );
    recommendations.push("Consider reducing training intensity temporarily");
  }

  if (avgHRV < 30) {
    recommendations.push(
      "Practice breathing exercises to improve autonomic balance"
    );
    recommendations.push("Consider meditation or yoga for HRV improvement");
  }

  return recommendations;
}

function generateEarlyWarnings(riskLevel, riskFactors) {
  const warnings = [];

  if (riskLevel === "high" || riskLevel === "critical") {
    warnings.push(
      "Elevated burnout risk detected - immediate attention recommended"
    );
  }

  if (riskFactors.includes("chronic_high_stress")) {
    warnings.push("Prolonged stress exposure may lead to health complications");
  }

  if (riskFactors.includes("chronic_sleep_deprivation")) {
    warnings.push("Sleep deprivation significantly increases health risks");
  }

  return warnings;
}

function generateInterventionRecommendations(riskLevel, riskFactors) {
  const interventions = [];

  if (riskLevel === "critical") {
    interventions.push("Seek immediate professional mental health support");
    interventions.push("Consider temporary workload reduction");
  }

  if (riskLevel === "high") {
    interventions.push("Schedule consultation with healthcare provider");
    interventions.push("Implement structured stress management program");
  }

  if (riskFactors.includes("inadequate_recovery")) {
    interventions.push("Prioritize recovery activities and rest periods");
  }

  return interventions;
}

function generateFallbackRecommendations(
  stressAnalysis,
  realTimeStress,
  burnoutRisk
) {
  return {
    immediate: [
      "Take 5 deep breaths",
      "Step away from stressful situation if possible",
      "Drink water and check posture",
    ],
    shortTerm: [
      "Schedule regular breaks throughout the day",
      "Practice stress reduction techniques",
      "Monitor sleep quality",
    ],
    longTerm: [
      "Develop consistent stress management routine",
      "Consider lifestyle modifications",
      "Regular health check-ups",
    ],
    lifestyle: {
      sleep: [
        "Maintain consistent sleep schedule",
        "Create relaxing bedtime routine",
      ],
      exercise: [
        "Regular moderate exercise",
        "Include stress-reducing activities",
      ],
      nutrition: ["Balanced diet", "Limit caffeine and alcohol"],
      mindfulness: ["Daily meditation practice", "Mindful breathing exercises"],
    },
    professional: {
      recommended:
        burnoutRisk.riskLevel === "high" ||
        burnoutRisk.riskLevel === "critical",
      urgency: burnoutRisk.riskLevel === "critical" ? "urgent" : "moderate",
      specialists: ["Primary care physician", "Mental health counselor"],
    },
    monitoring: [
      "Daily stress levels",
      "Sleep quality",
      "Heart rate variability",
    ],
    alerts: [
      "Sustained high stress",
      "Sleep disruption patterns",
      "Unusual biometric readings",
    ],
  };
}

function calculateOverallWellness(data) {
  let score = 1.0;

  if (data.realTimeStress.level === "severe") score -= 0.3;
  else if (data.realTimeStress.level === "high") score -= 0.2;
  else if (data.realTimeStress.level === "moderate") score -= 0.1;

  if (data.burnoutRisk.riskLevel === "critical") score -= 0.3;
  else if (data.burnoutRisk.riskLevel === "high") score -= 0.2;

  if (data.sleepImpact.stressImpact === "high") score -= 0.2;
  else if (data.sleepImpact.stressImpact === "moderate") score -= 0.1;

  if (data.anomalies.riskLevel === "high") score -= 0.1;

  score = Math.max(score, 0);

  if (score >= 0.8) return "excellent";
  if (score >= 0.6) return "good";
  if (score >= 0.4) return "fair";
  return "poor";
}

function extractKeyFindings(data) {
  const findings = [];

  if (
    data.realTimeStress.level === "high" ||
    data.realTimeStress.level === "severe"
  ) {
    findings.push(`Current stress level is ${data.realTimeStress.level}`);
  }

  if (data.stressAnalysis.stressTrends.direction === "worsening") {
    findings.push("Stress levels are trending upward");
  }

  if (
    data.burnoutRisk.riskLevel === "high" ||
    data.burnoutRisk.riskLevel === "critical"
  ) {
    findings.push(`Burnout risk is ${data.burnoutRisk.riskLevel}`);
  }

  if (data.anomalies.count > 3) {
    findings.push(`${data.anomalies.count} biometric anomalies detected`);
  }

  if (data.sleepImpact.stressImpact === "high") {
    findings.push(
      "Poor sleep quality is significantly impacting stress levels"
    );
  }

  return findings;
}

function calculateNextReviewDate(riskLevel) {
  const now = new Date();
  let daysToAdd;

  switch (riskLevel) {
    case "critical":
      daysToAdd = 1;
      break;
    case "high":
      daysToAdd = 3;
      break;
    case "moderate":
      daysToAdd = 7;
      break;
    default:
      daysToAdd = 14;
  }

  now.setDate(now.getDate() + daysToAdd);
  return now.toISOString().split("T")[0];
}
export async function POST(request) {
  return handler(await request.json());
}