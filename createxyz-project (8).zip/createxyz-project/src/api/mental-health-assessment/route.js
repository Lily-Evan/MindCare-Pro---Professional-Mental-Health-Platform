async function handler({
  responses,
  userProfile = {},
  previousAssessments = [],
  biometricData = {},
}) {
  if (!responses || typeof responses !== "object") {
    return {
      error: "Assessment responses are required",
      success: false,
    };
  }

  try {
    const currentDate = new Date().toISOString();

    const systemPrompt = `You are a specialized AI mental health assessment tool designed for healthcare professionals. Your role is to analyze mental health assessment data and provide evidence-based insights, risk assessments, and recommendations.

IMPORTANT DISCLAIMERS:
- This is a clinical decision support tool, not a replacement for professional judgment
- All assessments require validation by licensed mental health professionals
- Crisis situations require immediate professional intervention
- This tool is designed to assist, not replace, clinical assessment

Your analysis should focus on:
1. Work-related stress and burnout patterns
2. Depression and anxiety indicators
3. Sleep and lifestyle factors
4. Coping mechanisms and resilience
5. Social support systems
6. Risk factors and protective factors

Provide structured analysis in this exact JSON format:
{
  "assessment": {
    "overallRiskLevel": "low|moderate|high|critical",
    "riskScore": 0-100,
    "primaryConcerns": ["concern1", "concern2"],
    "protectiveFactors": ["factor1", "factor2"],
    "riskFactors": ["factor1", "factor2"]
  },
  "scores": {
    "depressionScore": 0-27,
    "anxietyScore": 0-21,
    "burnoutScore": 0-100,
    "stressLevel": 0-10,
    "sleepQuality": 0-10,
    "workLifeBalance": 0-10,
    "socialSupport": 0-10,
    "copingSkills": 0-10
  },
  "analysis": {
    "keyFindings": ["finding1", "finding2"],
    "patterns": ["pattern1", "pattern2"],
    "triggers": ["trigger1", "trigger2"],
    "strengths": ["strength1", "strength2"],
    "concernAreas": ["area1", "area2"]
  },
  "recommendations": {
    "immediate": ["action1", "action2"],
    "shortTerm": ["goal1", "goal2"],
    "longTerm": ["strategy1", "strategy2"],
    "lifestyle": ["change1", "change2"],
    "professional": ["referral1", "referral2"]
  },
  "treatmentOptions": {
    "therapy": ["CBT", "DBT", "EMDR"],
    "interventions": ["mindfulness", "stress management"],
    "medications": "consult psychiatrist for evaluation",
    "selfCare": ["exercise", "sleep hygiene"],
    "workplace": ["accommodations", "stress reduction"]
  },
  "crisis": {
    "isCrisis": false,
    "riskLevel": "none|low|moderate|high",
    "immediateActions": [],
    "emergencyContacts": [],
    "safetyPlan": []
  },
  "progress": {
    "comparison": "improvement|stable|decline|first_assessment",
    "trends": ["trend1", "trend2"],
    "milestones": ["milestone1", "milestone2"],
    "nextSteps": ["step1", "step2"]
  },
  "report": {
    "summary": "comprehensive clinical summary",
    "recommendations": "detailed professional recommendations",
    "followUp": "suggested follow-up timeline",
    "documentation": "clinical documentation notes"
  }
}

Base your analysis on established clinical scales and evidence-based practices. Consider work-related factors heavily in your assessment.`;

    const assessmentData = {
      responses: responses,
      userProfile: {
        age: userProfile.age || null,
        occupation: userProfile.occupation || "healthcare professional",
        workEnvironment: userProfile.workEnvironment || "clinical setting",
        yearsExperience: userProfile.yearsExperience || null,
        specialization: userProfile.specialization || null,
        workSchedule: userProfile.workSchedule || "standard",
        demographics: userProfile.demographics || {},
      },
      previousAssessments: previousAssessments.slice(-5), // Last 5 assessments
      biometricData: {
        heartRate: biometricData.heartRate || null,
        sleepHours: biometricData.sleepHours || null,
        stepsPerDay: biometricData.stepsPerDay || null,
        stressIndicators: biometricData.stressIndicators || [],
      },
      assessmentDate: currentDate,
    };

    const response = await fetch("/integrations/anthropic-claude-sonnet-3-5/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages: [
          {
            role: "user",
            content: `Analyze this mental health assessment data and provide comprehensive clinical insights:

Assessment Responses: ${JSON.stringify(responses)}

User Profile: ${JSON.stringify(assessmentData.userProfile)}

Previous Assessments: ${JSON.stringify(previousAssessments)}

Biometric Data: ${JSON.stringify(biometricData)}

Please provide a thorough analysis focusing on work-related mental health factors, burnout risk, and evidence-based recommendations for healthcare professionals.`,
          },
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`AI analysis failed: ${response.status}`);
    }

    const data = await response.json();

    if (!data.choices || !data.choices[0] || !data.choices[0].message) {
      throw new Error("Invalid response from AI service");
    }

    const aiAnalysis = data.choices[0].message.content;

    let analysisResult;
    try {
      const jsonMatch = aiAnalysis.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysisResult = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("No JSON found in AI response");
      }
    } catch (parseError) {
      analysisResult = createFallbackAssessment(responses);
    }

    // Validate and enhance the analysis
    const validatedResult = validateAndEnhanceAssessment(
      analysisResult,
      assessmentData
    );

    // Calculate trend analysis if previous assessments exist
    const trendAnalysis = calculateTrends(validatedResult, previousAssessments);

    // Generate professional report
    const professionalReport = generateProfessionalReport(
      validatedResult,
      assessmentData,
      trendAnalysis
    );

    return {
      success: true,
      assessment: validatedResult.assessment,
      scores: validatedResult.scores,
      analysis: validatedResult.analysis,
      recommendations: validatedResult.recommendations,
      treatmentOptions: validatedResult.treatmentOptions,
      crisis: validatedResult.crisis,
      progress: {
        ...validatedResult.progress,
        trends: trendAnalysis,
      },
      report: professionalReport,
      metadata: {
        assessmentId: generateAssessmentId(),
        timestamp: currentDate,
        version: "1.0",
        model: "claude-3-5-sonnet",
        processingTime: Date.now(),
        dataQuality: assessDataQuality(responses, userProfile),
        confidenceLevel: calculateConfidenceLevel(
          validatedResult,
          assessmentData
        ),
      },
      disclaimers: [
        "This assessment is a clinical decision support tool and requires professional validation",
        "Results should be interpreted by qualified mental health professionals",
        "Crisis situations require immediate professional intervention",
        "This tool supplements but does not replace clinical judgment",
      ],
      nextSteps: generateNextSteps(validatedResult),
      resources: generateResources(validatedResult.assessment.primaryConcerns),
    };
  } catch (error) {
    console.error("Mental health assessment error:", error);

    const fallbackAssessment = createFallbackAssessment(responses);

    return {
      error: "AI analysis encountered an issue, providing basic assessment",
      success: false,
      assessment: fallbackAssessment.assessment,
      scores: fallbackAssessment.scores,
      fallback: true,
      timestamp: new Date().toISOString(),
      errorType: error.message.includes("AI") ? "ai_error" : "processing_error",
      recommendations: {
        immediate: [
          "Consult with a mental health professional for proper assessment",
        ],
        professional: ["Schedule appointment with licensed clinician"],
      },
    };
  }
}

function validateAndEnhanceAssessment(result, assessmentData) {
  // Ensure all required fields exist with defaults
  const validated = {
    assessment: {
      overallRiskLevel: result.assessment?.overallRiskLevel || "moderate",
      riskScore: Math.min(Math.max(result.assessment?.riskScore || 50, 0), 100),
      primaryConcerns: result.assessment?.primaryConcerns || ["work stress"],
      protectiveFactors: result.assessment?.protectiveFactors || [],
      riskFactors: result.assessment?.riskFactors || [],
    },
    scores: {
      depressionScore: Math.min(
        Math.max(result.scores?.depressionScore || 0, 0),
        27
      ),
      anxietyScore: Math.min(Math.max(result.scores?.anxietyScore || 0, 0), 21),
      burnoutScore: Math.min(
        Math.max(result.scores?.burnoutScore || 0, 0),
        100
      ),
      stressLevel: Math.min(Math.max(result.scores?.stressLevel || 5, 0), 10),
      sleepQuality: Math.min(Math.max(result.scores?.sleepQuality || 5, 0), 10),
      workLifeBalance: Math.min(
        Math.max(result.scores?.workLifeBalance || 5, 0),
        10
      ),
      socialSupport: Math.min(
        Math.max(result.scores?.socialSupport || 5, 0),
        10
      ),
      copingSkills: Math.min(Math.max(result.scores?.copingSkills || 5, 0), 10),
    },
    analysis: result.analysis || {},
    recommendations: result.recommendations || {},
    treatmentOptions: result.treatmentOptions || {},
    crisis: {
      isCrisis: result.crisis?.isCrisis || false,
      riskLevel: result.crisis?.riskLevel || "none",
      immediateActions: result.crisis?.immediateActions || [],
      emergencyContacts: result.crisis?.emergencyContacts || [],
      safetyPlan: result.crisis?.safetyPlan || [],
    },
    progress: result.progress || {},
  };

  // Enhance crisis detection
  if (
    validated.scores.depressionScore > 20 ||
    validated.scores.anxietyScore > 15 ||
    validated.assessment.riskScore > 80
  ) {
    validated.crisis.riskLevel = "high";
    validated.crisis.immediateActions.push(
      "Immediate professional consultation required"
    );
  }

  return validated;
}

function calculateTrends(currentAssessment, previousAssessments) {
  if (!previousAssessments || previousAssessments.length === 0) {
    return {
      trend: "first_assessment",
      changes: [],
      improvements: [],
      concerns: [],
    };
  }

  const trends = {
    trend: "stable",
    changes: [],
    improvements: [],
    concerns: [],
  };

  const lastAssessment = previousAssessments[previousAssessments.length - 1];

  if (lastAssessment && lastAssessment.scores) {
    const currentScores = currentAssessment.scores;
    const previousScores = lastAssessment.scores;

    Object.keys(currentScores).forEach((key) => {
      if (previousScores[key] !== undefined) {
        const change = currentScores[key] - previousScores[key];
        if (Math.abs(change) > 1) {
          if (
            change > 0 &&
            (key === "depressionScore" ||
              key === "anxietyScore" ||
              key === "burnoutScore" ||
              key === "stressLevel")
          ) {
            trends.concerns.push(`${key} increased by ${change.toFixed(1)}`);
          } else if (
            change < 0 &&
            (key === "depressionScore" ||
              key === "anxietyScore" ||
              key === "burnoutScore" ||
              key === "stressLevel")
          ) {
            trends.improvements.push(
              `${key} decreased by ${Math.abs(change).toFixed(1)}`
            );
          } else if (
            change > 0 &&
            (key === "sleepQuality" ||
              key === "workLifeBalance" ||
              key === "socialSupport" ||
              key === "copingSkills")
          ) {
            trends.improvements.push(`${key} improved by ${change.toFixed(1)}`);
          } else if (
            change < 0 &&
            (key === "sleepQuality" ||
              key === "workLifeBalance" ||
              key === "socialSupport" ||
              key === "copingSkills")
          ) {
            trends.concerns.push(
              `${key} declined by ${Math.abs(change).toFixed(1)}`
            );
          }
        }
      }
    });
  }

  if (trends.improvements.length > trends.concerns.length) {
    trends.trend = "improvement";
  } else if (trends.concerns.length > trends.improvements.length) {
    trends.trend = "decline";
  }

  return trends;
}

function generateProfessionalReport(assessment, assessmentData, trends) {
  const date = new Date().toLocaleDateString();

  return {
    summary: `Mental Health Assessment Report - ${date}
    
Patient Profile: ${
      assessmentData.userProfile.occupation || "Healthcare Professional"
    }
Overall Risk Level: ${assessment.assessment.overallRiskLevel.toUpperCase()}
Risk Score: ${assessment.assessment.riskScore}/100

Key Findings:
- Primary concerns: ${assessment.assessment.primaryConcerns.join(", ")}
- Depression indicators: ${assessment.scores.depressionScore}/27
- Anxiety indicators: ${assessment.scores.anxietyScore}/21
- Burnout risk: ${assessment.scores.burnoutScore}/100
- Work-life balance: ${assessment.scores.workLifeBalance}/10

${
  trends.trend !== "first_assessment"
    ? `Trend Analysis: ${trends.trend}`
    : "Baseline assessment established"
}`,

    recommendations: `Clinical Recommendations:
    
Immediate Actions:
${
  assessment.recommendations.immediate?.map((rec) => `- ${rec}`).join("\n") ||
  "- Continue monitoring"
}

Short-term Goals:
${
  assessment.recommendations.shortTerm?.map((rec) => `- ${rec}`).join("\n") ||
  "- Establish baseline"
}

Professional Referrals:
${
  assessment.recommendations.professional
    ?.map((rec) => `- ${rec}`)
    .join("\n") || "- Regular follow-up recommended"
}`,

    followUp: assessment.crisis.isCrisis
      ? "Immediate follow-up required within 24-48 hours"
      : assessment.assessment.riskScore > 60
      ? "Follow-up recommended within 1-2 weeks"
      : "Routine follow-up in 4-6 weeks",

    documentation: `Assessment completed using AI-assisted clinical decision support tool. 
Risk level: ${assessment.assessment.overallRiskLevel}
Confidence level: High
Requires professional validation and clinical correlation.
Crisis protocol ${assessment.crisis.isCrisis ? "ACTIVATED" : "not indicated"}.`,
  };
}

function createFallbackAssessment(responses) {
  return {
    assessment: {
      overallRiskLevel: "moderate",
      riskScore: 50,
      primaryConcerns: ["work stress", "assessment incomplete"],
      protectiveFactors: [],
      riskFactors: ["incomplete data"],
    },
    scores: {
      depressionScore: 10,
      anxietyScore: 8,
      burnoutScore: 50,
      stressLevel: 6,
      sleepQuality: 5,
      workLifeBalance: 4,
      socialSupport: 5,
      copingSkills: 5,
    },
    analysis: {
      keyFindings: ["Assessment data incomplete"],
      patterns: [],
      triggers: [],
      strengths: [],
      concernAreas: ["data quality"],
    },
    recommendations: {
      immediate: [
        "Complete comprehensive assessment with mental health professional",
      ],
      shortTerm: ["Gather more detailed assessment data"],
      longTerm: ["Establish regular mental health monitoring"],
      lifestyle: ["Maintain basic self-care routines"],
      professional: ["Consult licensed mental health professional"],
    },
    treatmentOptions: {
      therapy: ["Professional assessment needed"],
      interventions: ["Basic stress management"],
      medications: "Professional evaluation required",
      selfCare: ["Regular exercise", "adequate sleep"],
      workplace: ["Discuss with supervisor if appropriate"],
    },
    crisis: {
      isCrisis: false,
      riskLevel: "unknown",
      immediateActions: ["Seek professional assessment"],
      emergencyContacts: [],
      safetyPlan: [],
    },
    progress: {
      comparison: "first_assessment",
      trends: [],
      milestones: [],
      nextSteps: ["Complete full assessment"],
    },
  };
}

function assessDataQuality(responses, userProfile) {
  let quality = 0;

  if (responses && Object.keys(responses).length > 0) quality += 40;
  if (userProfile && Object.keys(userProfile).length > 0) quality += 30;
  if (responses && Object.keys(responses).length > 10) quality += 20;
  if (userProfile && userProfile.age && userProfile.occupation) quality += 10;

  return Math.min(quality, 100);
}

function calculateConfidenceLevel(assessment, assessmentData) {
  let confidence = 0.5;

  if (
    assessmentData.userProfile &&
    Object.keys(assessmentData.userProfile).length > 3
  ) {
    confidence += 0.2;
  }

  if (
    assessmentData.responses &&
    Object.keys(assessmentData.responses).length > 10
  ) {
    confidence += 0.2;
  }

  if (
    assessmentData.previousAssessments &&
    assessmentData.previousAssessments.length > 0
  ) {
    confidence += 0.1;
  }

  return Math.min(confidence, 1.0);
}

function generateNextSteps(assessment) {
  const steps = [];

  if (assessment.crisis.isCrisis) {
    steps.push("Immediate crisis intervention required");
    steps.push("Contact emergency services if imminent danger");
  }

  if (assessment.assessment.riskScore > 70) {
    steps.push("Schedule urgent appointment with mental health professional");
  } else if (assessment.assessment.riskScore > 40) {
    steps.push(
      "Schedule appointment with mental health professional within 2 weeks"
    );
  }

  steps.push("Implement recommended self-care strategies");
  steps.push("Monitor symptoms and mood daily");
  steps.push("Follow up assessment in 2-4 weeks");

  return steps;
}

function generateResources(primaryConcerns) {
  const resources = {
    crisis: [
      "National Suicide Prevention Lifeline: 988",
      "Crisis Text Line: Text HOME to 741741",
      "Emergency Services: 911",
    ],
    professional: [
      "Psychology Today therapist directory",
      "Employee Assistance Program (if available)",
      "Primary care physician referral",
    ],
    selfHelp: [
      "Mindfulness and meditation apps",
      "Cognitive behavioral therapy workbooks",
      "Stress management techniques",
    ],
    workplace: [
      "HR department mental health resources",
      "Workplace wellness programs",
      "Professional development for stress management",
    ],
  };

  return resources;
}

function generateAssessmentId() {
  return "mha_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
}
export async function POST(request) {
  return handler(await request.json());
}