"use client";
import React from "react";

import { useHandleStreamResponse } from "../utilities/runtime-helpers";

function MainComponent() {
  const [activeSection, setActiveSection] = React.useState("dashboard");
  const [user, setUser] = React.useState({
    name: "Dr. Maria Papadopoulos",
    profession: "Cardiologist",
    stressLevel: "moderate",
    lastCheckIn: "2 hours ago",
    age: 35,
    occupation: "Healthcare Professional",
    workEnvironment: "clinical setting",
    yearsExperience: 10,
    specialization: "General Practice",
  });
  const [wearableData, setWearableData] = React.useState({
    heartRate: 72,
    hrv: 45,
    sleepQuality: 85,
    stressLevel: 6.2,
    activityLevel: "moderate",
  });
  const [appointments, setAppointments] = React.useState([
    {
      id: 1,
      type: "Therapy Session",
      time: "14:00",
      therapist: "Dr. John Smith",
      date: "Today",
    },
    {
      id: 2,
      type: "Wellness Check",
      time: "10:30",
      therapist: "Dr. Sarah Johnson",
      date: "Tomorrow",
    },
  ]);
  const [moodData, setMoodData] = React.useState([
    { date: "2025-01-15", mood: 7, stress: 4, energy: 6 },
    { date: "2025-01-14", mood: 6, stress: 6, energy: 5 },
    { date: "2025-01-13", mood: 8, stress: 3, energy: 7 },
  ]);
  const [showEmergency, setShowEmergency] = React.useState(false);
  const [chatMessages, setChatMessages] = React.useState([]);
  const [currentMessage, setCurrentMessage] = React.useState("");
  const [isTyping, setIsTyping] = React.useState(false);
  const [assessmentAnswers, setAssessmentAnswers] = React.useState({});
  const [assessmentResults, setAssessmentResults] = React.useState(null);
  const [journalEntry, setJournalEntry] = React.useState("");
  const [meditationActive, setMeditationActive] = React.useState(false);
  const [breathingActive, setBreathingActive] = React.useState(false);
  const [breathingCount, setBreathingCount] = React.useState(0);

  const handleStreamResponse = useHandleStreamResponse({
    onChunk: (chunk) => {
      setIsTyping(true);
      setChatMessages((prev) => {
        const newMessages = [...prev];
        const lastMessage = newMessages[newMessages.length - 1];
        if (
          lastMessage &&
          lastMessage.sender === "ai" &&
          lastMessage.isStreaming
        ) {
          lastMessage.content += chunk;
        } else {
          newMessages.push({
            sender: "ai",
            content: chunk,
            isStreaming: true,
            timestamp: new Date(),
          });
        }
        return newMessages;
      });
    },
    onFinish: (fullMessage) => {
      setIsTyping(false);
      setChatMessages((prev) => {
        const newMessages = [...prev];
        const lastMessage = newMessages[newMessages.length - 1];
        if (lastMessage && lastMessage.sender === "ai") {
          lastMessage.content = fullMessage;
          lastMessage.isStreaming = false;
        }
        return newMessages;
      });
    },
  });

  const sendMessage = async () => {
    if (!currentMessage.trim()) return;

    const userMessage = {
      sender: "user",
      content: currentMessage,
      timestamp: new Date(),
    };

    setChatMessages((prev) => [...prev, userMessage]);
    setCurrentMessage("");

    try {
      const response = await fetch(
        "/integrations/anthropic-claude-sonnet-3-5/",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [
              {
                role: "system",
                content:
                  "You are a compassionate AI mental health counselor for healthcare professionals. Provide supportive, evidence-based guidance while being empathetic and professional. Always remind users to seek immediate help if they express suicidal thoughts or are in crisis.",
              },
              ...chatMessages.map((msg) => ({
                role: msg.sender === "user" ? "user" : "assistant",
                content: msg.content,
              })),
              { role: "user", content: currentMessage },
            ],
            stream: true,
          }),
        }
      );

      handleStreamResponse(response);
    } catch (error) {
      console.error("Error sending message:", error);
      setChatMessages((prev) => [
        ...prev,
        {
          sender: "ai",
          content:
            "I apologize, but I'm having trouble connecting right now. Please try again or contact emergency services if this is urgent.",
          timestamp: new Date(),
        },
      ]);
    }
  };

  const performAssessment = async () => {
    try {
      const response = await fetch("/api/mental-health-assessment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          responses: assessmentAnswers,
          userProfile: {
            age: user.age || 35,
            occupation: user.profession || "Healthcare Professional",
            workEnvironment: "clinical setting",
            yearsExperience: user.yearsExperience || 10,
            specialization: user.specialization || "General Practice",
          },
          previousAssessments: [],
          biometricData: wearableData,
        }),
      });

      if (!response.ok) {
        throw new Error("Assessment analysis failed");
      }

      const data = await response.json();

      if (data.success) {
        setAssessmentResults(data);
      } else {
        throw new Error(data.error || "Assessment failed");
      }
    } catch (error) {
      console.error("Assessment error:", error);
      // Fallback assessment results
      setAssessmentResults({
        assessment: {
          riskLevel: "moderate",
          overallScore: 65,
          primaryConcerns: ["work stress", "sleep quality"],
          protectiveFactors: ["professional support", "health awareness"],
          riskFactors: ["high workload", "irregular schedule"],
        },
        recommendations: {
          immediate: ["Take regular breaks", "Practice deep breathing"],
          shortTerm: ["Improve sleep hygiene", "Schedule stress management"],
          longTerm: [
            "Work-life balance improvement",
            "Professional development",
          ],
        },
        scores: {
          depressionScore: 8,
          anxietyScore: 12,
          burnoutScore: 45,
          stressLevel: 6,
          sleepQuality: 6,
          workLifeBalance: 5,
        },
      });
    }
  };

  const startBreathingExercise = () => {
    setBreathingActive(true);
    setBreathingCount(0);

    const breathingCycle = () => {
      if (breathingCount < 20) {
        setBreathingCount((prev) => prev + 1);
        setTimeout(breathingCycle, 4000);
      } else {
        setBreathingActive(false);
      }
    };

    breathingCycle();
  };

  const getStressColor = (level) => {
    if (level <= 3) return "text-green-600 bg-green-100";
    if (level <= 6) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  const navigation = [
    { id: "dashboard", label: "Dashboard", icon: "fas fa-tachometer-alt" },
    { id: "assessment", label: "AI Assessment", icon: "fas fa-brain" },
    { id: "support", label: "Support Chat", icon: "fas fa-comments" },
    { id: "wellness", label: "Wellness Tools", icon: "fas fa-leaf" },
    { id: "wearables", label: "Biometrics", icon: "fas fa-heartbeat" },
    { id: "telemedicine", label: "Telemedicine", icon: "fas fa-video" },
    { id: "professional", label: "Work-Life", icon: "fas fa-briefcase" },
  ];

  const updateWearableData = async () => {
    try {
      const response = await fetch("/api/wearables-monitor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          biometricData: {
            heartRate: [
              {
                value: wearableData.heartRate,
                timestamp: new Date().toISOString(),
              },
            ],
            hrv: [
              { rmssd: wearableData.hrv, timestamp: new Date().toISOString() },
            ],
            sleep: {
              duration: 7.5,
              quality: wearableData.sleepQuality / 100,
              efficiency: 0.85,
              awakenings: 2,
            },
            activity: [
              {
                steps: 8500,
                intensity: wearableData.activityLevel,
                timestamp: new Date().toISOString(),
              },
            ],
          },
          deviceType: "smartwatch",
          timeRange: "24h",
          userProfile: {
            age: 35,
            gender: "unspecified",
            fitnessLevel: "moderate",
            profession: user.profession,
          },
          historicalData: {},
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          // Update wearable data with AI insights
          setWearableData((prev) => ({
            ...prev,
            stressLevel: data.realTimeStress.score * 10,
            aiInsights: data.stressAnalysis,
            recommendations: data.recommendations,
            alerts: data.alerts,
          }));
        }
      }
    } catch (error) {
      console.error("Wearables monitoring error:", error);
    }
  };

  React.useEffect(() => {
    const interval = setInterval(updateWearableData, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Emergency Modal */}
      {showEmergency && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <div className="text-center">
              <i className="fas fa-exclamation-triangle text-red-500 text-4xl mb-4"></i>
              <h3 className="text-xl font-bold text-gray-900 mb-4 font-inter">
                Emergency Support
              </h3>
              <p className="text-gray-600 mb-6 font-inter">
                If you're experiencing a mental health crisis, please contact:
              </p>

              <div className="space-y-3 mb-6">
                <div className="p-3 bg-red-50 rounded-lg">
                  <div className="font-semibold text-red-800 font-inter">
                    Crisis Hotline
                  </div>
                  <div className="text-red-600 font-inter">
                    988 (US) | 116 123 (EU)
                  </div>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg">
                  <div className="font-semibold text-blue-800 font-inter">
                    Emergency Services
                  </div>
                  <div className="text-blue-600 font-inter">
                    911 (US) | 112 (EU)
                  </div>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <div className="font-semibold text-green-800 font-inter">
                    24/7 Text Support
                  </div>
                  <div className="text-green-600 font-inter">
                    Text HOME to 741741
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowEmergency(false)}
                className="w-full py-2 px-4 bg-gray-600 text-white rounded-lg hover:bg-gray-700 font-inter"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <i className="fas fa-heart text-2xl text-blue-600 mr-3"></i>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 font-inter">
                  MindCare Pro
                </h1>
                <p className="text-sm text-gray-600 font-inter">
                  Professional Mental Health Platform
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowEmergency(true)}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 font-inter"
              >
                <i className="fas fa-exclamation-triangle mr-2"></i>
                Emergency
              </button>
              <div className="text-right">
                <div className="font-semibold text-gray-900 font-inter">
                  {user.name}
                </div>
                <div className="text-sm text-gray-600 font-inter">
                  {user.profession}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar Navigation */}
          <div className="lg:w-64">
            <div className="bg-white rounded-lg shadow-sm p-4">
              <nav className="space-y-2">
                {navigation.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveSection(item.id)}
                    className={`w-full flex items-center px-3 py-2 rounded-lg text-left font-inter transition-colors ${
                      activeSection === item.id
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-600 hover:bg-gray-100"
                    }`}
                  >
                    <i className={`${item.icon} mr-3`}></i>
                    {item.label}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Dashboard */}
            {activeSection === "dashboard" && (
              <div className="space-y-6">
                {/* Quick Stats */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-white rounded-lg shadow-sm p-4">
                    <div className="flex items-center">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <i className="fas fa-heartbeat text-blue-600"></i>
                      </div>
                      <div className="ml-3">
                        <div className="text-sm text-gray-600 font-inter">
                          Heart Rate
                        </div>
                        <div className="text-xl font-bold text-gray-900 font-inter">
                          {wearableData.heartRate} BPM
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-sm p-4">
                    <div className="flex items-center">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <i className="fas fa-bed text-green-600"></i>
                      </div>
                      <div className="ml-3">
                        <div className="text-sm text-gray-600 font-inter">
                          Sleep Quality
                        </div>
                        <div className="text-xl font-bold text-gray-900 font-inter">
                          {wearableData.sleepQuality}%
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-sm p-4">
                    <div className="flex items-center">
                      <div className="p-2 bg-yellow-100 rounded-lg">
                        <i className="fas fa-brain text-yellow-600"></i>
                      </div>
                      <div className="ml-3">
                        <div className="text-sm text-gray-600 font-inter">
                          Stress Level
                        </div>
                        <div
                          className={`text-xl font-bold font-inter ${
                            getStressColor(wearableData.stressLevel).split(
                              " "
                            )[0]
                          }`}
                        >
                          {wearableData.stressLevel}/10
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-sm p-4">
                    <div className="flex items-center">
                      <div className="p-2 bg-purple-100 rounded-lg">
                        <i className="fas fa-running text-purple-600"></i>
                      </div>
                      <div className="ml-3">
                        <div className="text-sm text-gray-600 font-inter">
                          Activity
                        </div>
                        <div className="text-xl font-bold text-gray-900 font-inter capitalize">
                          {wearableData.activityLevel}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Daily Check-in */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 font-inter">
                    <i className="fas fa-clipboard-check text-blue-600 mr-2"></i>
                    Daily Wellness Check-in
                  </h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2 font-inter">
                        Mood (1-10)
                      </label>
                      <input type="range" min="1" max="10" className="w-full" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2 font-inter">
                        Energy (1-10)
                      </label>
                      <input type="range" min="1" max="10" className="w-full" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2 font-inter">
                        Stress (1-10)
                      </label>
                      <input type="range" min="1" max="10" className="w-full" />
                    </div>
                  </div>
                  <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-inter">
                    Submit Check-in
                  </button>
                </div>

                {/* Upcoming Appointments */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 font-inter">
                    <i className="fas fa-calendar text-green-600 mr-2"></i>
                    Upcoming Sessions
                  </h3>
                  <div className="space-y-3">
                    {appointments.map((apt) => (
                      <div
                        key={apt.id}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                      >
                        <div>
                          <div className="font-semibold text-gray-900 font-inter">
                            {apt.type}
                          </div>
                          <div className="text-sm text-gray-600 font-inter">
                            with {apt.therapist}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-blue-600 font-inter">
                            {apt.time}
                          </div>
                          <div className="text-sm text-gray-600 font-inter">
                            {apt.date}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* AI Assessment */}
            {activeSection === "assessment" && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-6 font-inter">
                  <i className="fas fa-brain text-purple-600 mr-2"></i>
                  AI Mental Health Assessment
                </h3>

                {!assessmentResults ? (
                  <div className="space-y-6">
                    <div className="grid gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 font-inter">
                          How often have you felt down, depressed, or hopeless
                          in the past 2 weeks?
                        </label>
                        <select
                          className="w-full p-2 border border-gray-300 rounded-lg font-inter"
                          onChange={(e) =>
                            setAssessmentAnswers({
                              ...assessmentAnswers,
                              depression: e.target.value,
                            })
                          }
                        >
                          <option value="">Select...</option>
                          <option value="not-at-all">Not at all</option>
                          <option value="several-days">Several days</option>
                          <option value="more-than-half">
                            More than half the days
                          </option>
                          <option value="nearly-every-day">
                            Nearly every day
                          </option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 font-inter">
                          How often have you felt nervous, anxious, or on edge?
                        </label>
                        <select
                          className="w-full p-2 border border-gray-300 rounded-lg font-inter"
                          onChange={(e) =>
                            setAssessmentAnswers({
                              ...assessmentAnswers,
                              anxiety: e.target.value,
                            })
                          }
                        >
                          <option value="">Select...</option>
                          <option value="not-at-all">Not at all</option>
                          <option value="several-days">Several days</option>
                          <option value="more-than-half">
                            More than half the days
                          </option>
                          <option value="nearly-every-day">
                            Nearly every day
                          </option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 font-inter">
                          How would you rate your current stress level at work?
                        </label>
                        <select
                          className="w-full p-2 border border-gray-300 rounded-lg font-inter"
                          onChange={(e) =>
                            setAssessmentAnswers({
                              ...assessmentAnswers,
                              workStress: e.target.value,
                            })
                          }
                        >
                          <option value="">Select...</option>
                          <option value="low">Low</option>
                          <option value="moderate">Moderate</option>
                          <option value="high">High</option>
                          <option value="severe">Severe</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 font-inter">
                          How is your sleep quality?
                        </label>
                        <select
                          className="w-full p-2 border border-gray-300 rounded-lg font-inter"
                          onChange={(e) =>
                            setAssessmentAnswers({
                              ...assessmentAnswers,
                              sleep: e.target.value,
                            })
                          }
                        >
                          <option value="">Select...</option>
                          <option value="excellent">Excellent</option>
                          <option value="good">Good</option>
                          <option value="fair">Fair</option>
                          <option value="poor">Poor</option>
                        </select>
                      </div>
                    </div>

                    <button
                      onClick={performAssessment}
                      className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-inter"
                      disabled={Object.keys(assessmentAnswers).length < 4}
                    >
                      <i className="fas fa-chart-line mr-2"></i>
                      Analyze Results
                    </button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-bold text-blue-900 mb-2 font-inter">
                        Assessment Results
                      </h4>
                      <div className="text-2xl font-bold text-blue-700 font-inter">
                        Risk Level: {assessmentResults.riskLevel}
                      </div>
                      <div className="text-lg text-blue-600 font-inter">
                        Overall Score: {assessmentResults.overallScore}/100
                      </div>
                    </div>

                    <div>
                      <h4 className="font-bold text-gray-900 mb-3 font-inter">
                        Key Findings
                      </h4>
                      <ul className="space-y-2">
                        {assessmentResults.keyFindings.map((finding, index) => (
                          <li key={index} className="flex items-start">
                            <i className="fas fa-check-circle text-green-500 mr-2 mt-1"></i>
                            <span className="text-gray-700 font-inter">
                              {finding}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-bold text-gray-900 mb-3 font-inter">
                        Recommendations
                      </h4>
                      <ul className="space-y-2">
                        {assessmentResults.recommendations.map((rec, index) => (
                          <li key={index} className="flex items-start">
                            <i className="fas fa-lightbulb text-yellow-500 mr-2 mt-1"></i>
                            <span className="text-gray-700 font-inter">
                              {rec}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <button
                      onClick={() => setAssessmentResults(null)}
                      className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 font-inter"
                    >
                      Take New Assessment
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Support Chat */}
            {activeSection === "support" && (
              <div className="bg-white rounded-lg shadow-sm p-6 h-[600px] flex flex-col">
                <h3 className="text-xl font-bold text-gray-900 mb-4 font-inter">
                  <i className="fas fa-comments text-green-600 mr-2"></i>
                  24/7 AI Counselor
                </h3>

                <div className="flex-1 overflow-y-auto mb-4 space-y-4">
                  {chatMessages.length === 0 && (
                    <div className="text-center text-gray-500 font-inter">
                      <i className="fas fa-heart text-4xl text-green-400 mb-4"></i>
                      <p>
                        Hello! I'm here to provide support and guidance. How are
                        you feeling today?
                      </p>
                    </div>
                  )}

                  {chatMessages.map((message, index) => (
                    <div
                      key={index}
                      className={`flex ${
                        message.sender === "user"
                          ? "justify-end"
                          : "justify-start"
                      }`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg font-inter ${
                          message.sender === "user"
                            ? "bg-blue-600 text-white"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {message.content}
                      </div>
                    </div>
                  ))}

                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="bg-gray-100 px-4 py-2 rounded-lg font-inter">
                        <i className="fas fa-ellipsis-h"></i> Typing...
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={currentMessage}
                    onChange={(e) => setCurrentMessage(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                    placeholder="Type your message..."
                    className="flex-1 p-2 border border-gray-300 rounded-lg font-inter"
                  />
                  <button
                    onClick={sendMessage}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-inter"
                  >
                    <i className="fas fa-paper-plane"></i>
                  </button>
                </div>
              </div>
            )}

            {/* Wellness Tools */}
            {activeSection === "wellness" && (
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Mood Tracking */}
                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <h3 className="text-lg font-bold text-gray-900 mb-4 font-inter">
                      <i className="fas fa-smile text-yellow-600 mr-2"></i>
                      Mood Tracking
                    </h3>
                    <div className="space-y-4">
                      {moodData.map((entry, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                        >
                          <div className="text-sm text-gray-600 font-inter">
                            {entry.date}
                          </div>
                          <div className="flex space-x-4">
                            <span className="text-sm font-inter">
                              Mood: {entry.mood}/10
                            </span>
                            <span className="text-sm font-inter">
                              Stress: {entry.stress}/10
                            </span>
                            <span className="text-sm font-inter">
                              Energy: {entry.energy}/10
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Breathing Exercise */}
                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <h3 className="text-lg font-bold text-gray-900 mb-4 font-inter">
                      <i className="fas fa-wind text-blue-600 mr-2"></i>
                      Breathing Exercise
                    </h3>
                    <div className="text-center">
                      {!breathingActive ? (
                        <div>
                          <p className="text-gray-600 mb-4 font-inter">
                            Take a moment to practice deep breathing
                          </p>
                          <button
                            onClick={startBreathingExercise}
                            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-inter"
                          >
                            Start Exercise
                          </button>
                        </div>
                      ) : (
                        <div>
                          <div className="text-4xl mb-4">
                            <i className="fas fa-circle text-blue-400"></i>
                          </div>
                          <p className="text-lg font-semibold text-blue-600 mb-2 font-inter">
                            Breath {breathingCount}/20
                          </p>
                          <p className="text-gray-600 font-inter">
                            Breathe in... hold... breathe out...
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Journal */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 font-inter">
                    <i className="fas fa-book text-purple-600 mr-2"></i>
                    Daily Journal
                  </h3>
                  <textarea
                    value={journalEntry}
                    onChange={(e) => setJournalEntry(e.target.value)}
                    placeholder="Write about your thoughts and feelings today..."
                    className="w-full h-32 p-3 border border-gray-300 rounded-lg font-inter"
                  />
                  <button className="mt-3 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-inter">
                    Save Entry
                  </button>
                </div>

                {/* Meditation */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 font-inter">
                    <i className="fas fa-leaf text-green-600 mr-2"></i>
                    Guided Meditation
                  </h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="p-4 bg-green-50 rounded-lg text-center">
                      <i className="fas fa-clock text-green-600 text-2xl mb-2"></i>
                      <h4 className="font-semibold text-green-800 font-inter">
                        5-Minute Calm
                      </h4>
                      <p className="text-sm text-green-600 font-inter">
                        Quick stress relief
                      </p>
                    </div>
                    <div className="p-4 bg-blue-50 rounded-lg text-center">
                      <i className="fas fa-moon text-blue-600 text-2xl mb-2"></i>
                      <h4 className="font-semibold text-blue-800 font-inter">
                        Sleep Meditation
                      </h4>
                      <p className="text-sm text-blue-600 font-inter">
                        Better rest
                      </p>
                    </div>
                    <div className="p-4 bg-purple-50 rounded-lg text-center">
                      <i className="fas fa-brain text-purple-600 text-2xl mb-2"></i>
                      <h4 className="font-semibold text-purple-800 font-inter">
                        Mindfulness
                      </h4>
                      <p className="text-sm text-purple-600 font-inter">
                        Present moment
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Wearables/Biometrics */}
            {activeSection === "wearables" && (
              <div className="space-y-6">
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-6 font-inter">
                    <i className="fas fa-heartbeat text-red-600 mr-2"></i>
                    Biometric Monitoring
                  </h3>

                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="p-4 bg-red-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-red-800 font-inter">
                          Heart Rate
                        </h4>
                        <i className="fas fa-heart text-red-600"></i>
                      </div>
                      <div className="text-2xl font-bold text-red-700 font-inter">
                        {wearableData.heartRate} BPM
                      </div>
                      <div className="text-sm text-red-600 font-inter">
                        Normal range
                      </div>
                    </div>

                    <div className="p-4 bg-blue-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-blue-800 font-inter">
                          HRV
                        </h4>
                        <i className="fas fa-chart-line text-blue-600"></i>
                      </div>
                      <div className="text-2xl font-bold text-blue-700 font-inter">
                        {wearableData.hrv} ms
                      </div>
                      <div className="text-sm text-blue-600 font-inter">
                        Good variability
                      </div>
                    </div>

                    <div className="p-4 bg-green-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-green-800 font-inter">
                          Sleep Quality
                        </h4>
                        <i className="fas fa-bed text-green-600"></i>
                      </div>
                      <div className="text-2xl font-bold text-green-700 font-inter">
                        {wearableData.sleepQuality}%
                      </div>
                      <div className="text-sm text-green-600 font-inter">
                        Excellent
                      </div>
                    </div>

                    <div className="p-4 bg-yellow-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-yellow-800 font-inter">
                          Stress Level
                        </h4>
                        <i className="fas fa-brain text-yellow-600"></i>
                      </div>
                      <div className="text-2xl font-bold text-yellow-700 font-inter">
                        {wearableData.stressLevel}/10
                      </div>
                      <div className="text-sm text-yellow-600 font-inter">
                        Moderate
                      </div>
                    </div>

                    <div className="p-4 bg-purple-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-purple-800 font-inter">
                          Activity
                        </h4>
                        <i className="fas fa-running text-purple-600"></i>
                      </div>
                      <div className="text-2xl font-bold text-purple-700 font-inter capitalize">
                        {wearableData.activityLevel}
                      </div>
                      <div className="text-sm text-purple-600 font-inter">
                        On track
                      </div>
                    </div>

                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-gray-800 font-inter">
                          Device Status
                        </h4>
                        <i className="fas fa-check-circle text-green-600"></i>
                      </div>
                      <div className="text-lg font-bold text-gray-700 font-inter">
                        Connected
                      </div>
                      <div className="text-sm text-gray-600 font-inter">
                        Last sync: 2 min ago
                      </div>
                    </div>
                  </div>
                </div>

                {/* Alerts */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 font-inter">
                    <i className="fas fa-bell text-orange-600 mr-2"></i>
                    Health Alerts
                  </h3>
                  <div className="space-y-3">
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-center">
                        <i className="fas fa-exclamation-triangle text-yellow-600 mr-2"></i>
                        <span className="font-semibold text-yellow-800 font-inter">
                          Elevated Stress Detected
                        </span>
                      </div>
                      <p className="text-sm text-yellow-700 mt-1 font-inter">
                        Your stress levels have been elevated for the past 2
                        hours. Consider taking a break.
                      </p>
                    </div>
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-center">
                        <i className="fas fa-info-circle text-blue-600 mr-2"></i>
                        <span className="font-semibold text-blue-800 font-inter">
                          Sleep Reminder
                        </span>
                      </div>
                      <p className="text-sm text-blue-700 mt-1 font-inter">
                        You've been getting less than 7 hours of sleep. Try to
                        maintain a consistent sleep schedule.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Telemedicine */}
            {activeSection === "telemedicine" && (
              <div className="space-y-6">
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-6 font-inter">
                    <i className="fas fa-video text-blue-600 mr-2"></i>
                    Telemedicine Services
                  </h3>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-3 font-inter">
                        Book Consultation
                      </h4>
                      <div className="space-y-3">
                        <select className="w-full p-2 border border-gray-300 rounded-lg font-inter">
                          <option>Select Therapist</option>
                          <option>Dr. Sarah Johnson - Psychiatrist</option>
                          <option>Dr. Michael Chen - Psychologist</option>
                          <option>Dr. Emily Davis - Counselor</option>
                        </select>
                        <input
                          type="date"
                          className="w-full p-2 border border-gray-300 rounded-lg font-inter"
                        />
                        <select className="w-full p-2 border border-gray-300 rounded-lg font-inter">
                          <option>Select Time</option>
                          <option>09:00 AM</option>
                          <option>11:00 AM</option>
                          <option>02:00 PM</option>
                          <option>04:00 PM</option>
                        </select>
                        <button className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-inter">
                          Book Appointment
                        </button>
                      </div>
                    </div>

                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-3 font-inter">
                        Quick Actions
                      </h4>
                      <div className="space-y-2">
                        <button className="w-full p-3 text-left bg-green-50 hover:bg-green-100 rounded-lg font-inter">
                          <i className="fas fa-comments text-green-600 mr-2"></i>
                          Message Therapist
                        </button>
                        <button className="w-full p-3 text-left bg-blue-50 hover:bg-blue-100 rounded-lg font-inter">
                          <i className="fas fa-prescription-bottle text-blue-600 mr-2"></i>
                          Prescription Refill
                        </button>
                        <button className="w-full p-3 text-left bg-purple-50 hover:bg-purple-100 rounded-lg font-inter">
                          <i className="fas fa-file-medical text-purple-600 mr-2"></i>
                          Medical Records
                        </button>
                        <button className="w-full p-3 text-left bg-orange-50 hover:bg-orange-100 rounded-lg font-inter">
                          <i className="fas fa-credit-card text-orange-600 mr-2"></i>
                          Billing & Insurance
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Treatment Plan */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 font-inter">
                    <i className="fas fa-clipboard-list text-green-600 mr-2"></i>
                    Current Treatment Plan
                  </h3>
                  <div className="space-y-4">
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <h4 className="font-semibold text-gray-900 font-inter">
                        Cognitive Behavioral Therapy
                      </h4>
                      <p className="text-sm text-gray-600 font-inter">
                        Weekly sessions with Dr. Sarah Johnson
                      </p>
                      <div className="mt-2">
                        <div className="flex justify-between text-sm font-inter">
                          <span>Progress</span>
                          <span>6/12 sessions</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                          <div className="bg-green-600 h-2 rounded-full w-1/2"></div>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-gray-50 rounded-lg">
                      <h4 className="font-semibold text-gray-900 font-inter">
                        Medication Management
                      </h4>
                      <p className="text-sm text-gray-600 font-inter">
                        Sertraline 50mg daily
                      </p>
                      <p className="text-xs text-gray-500 mt-1 font-inter">
                        Next review: March 15, 2025
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Professional/Work-Life */}
            {activeSection === "professional" && (
              <div className="space-y-6">
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-6 font-inter">
                    <i className="fas fa-briefcase text-indigo-600 mr-2"></i>
                    Work-Life Balance Assessment
                  </h3>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-4 font-inter">
                        Burnout Risk Factors
                      </h4>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                          <span className="text-red-800 font-inter">
                            Work Hours/Week
                          </span>
                          <span className="font-bold text-red-700 font-inter">
                            65 hrs
                          </span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                          <span className="text-yellow-800 font-inter">
                            Overtime Frequency
                          </span>
                          <span className="font-bold text-yellow-700 font-inter">
                            High
                          </span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                          <span className="text-green-800 font-inter">
                            Job Satisfaction
                          </span>
                          <span className="font-bold text-green-700 font-inter">
                            7/10
                          </span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-4 font-inter">
                        Recommendations
                      </h4>
                      <div className="space-y-3">
                        <div className="p-3 bg-blue-50 rounded-lg">
                          <i className="fas fa-clock text-blue-600 mr-2"></i>
                          <span className="text-blue-800 font-inter">
                            Schedule regular breaks
                          </span>
                        </div>
                        <div className="p-3 bg-green-50 rounded-lg">
                          <i className="fas fa-users text-green-600 mr-2"></i>
                          <span className="text-green-800 font-inter">
                            Join peer support group
                          </span>
                        </div>
                        <div className="p-3 bg-purple-50 rounded-lg">
                          <i className="fas fa-dumbbell text-purple-600 mr-2"></i>
                          <span className="text-purple-800 font-inter">
                            Increase physical activity
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Career Resources */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 font-inter">
                    <i className="fas fa-graduation-cap text-blue-600 mr-2"></i>
                    Professional Development
                  </h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="p-4 border border-gray-200 rounded-lg text-center">
                      <i className="fas fa-book text-blue-600 text-2xl mb-2"></i>
                      <h4 className="font-semibold text-gray-900 font-inter">
                        Continuing Education
                      </h4>
                      <p className="text-sm text-gray-600 font-inter">
                        CME courses and certifications
                      </p>
                    </div>
                    <div className="p-4 border border-gray-200 rounded-lg text-center">
                      <i className="fas fa-handshake text-green-600 text-2xl mb-2"></i>
                      <h4 className="font-semibold text-gray-900 font-inter">
                        Mentorship
                      </h4>
                      <p className="text-sm text-gray-600 font-inter">
                        Connect with senior professionals
                      </p>
                    </div>
                    <div className="p-4 border border-gray-200 rounded-lg text-center">
                      <i className="fas fa-network-wired text-purple-600 text-2xl mb-2"></i>
                      <h4 className="font-semibold text-gray-900 font-inter">
                        Networking
                      </h4>
                      <p className="text-sm text-gray-600 font-inter">
                        Professional associations
                      </p>
                    </div>
                  </div>
                </div>

                {/* Peer Support */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 font-inter">
                    <i className="fas fa-users text-green-600 mr-2"></i>
                    Peer Support Groups
                  </h3>
                  <div className="space-y-3">
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold text-gray-900 font-inter">
                            Healthcare Workers Support
                          </h4>
                          <p className="text-sm text-gray-600 font-inter">
                            Weekly group sessions for medical professionals
                          </p>
                        </div>
                        <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-inter">
                          Join
                        </button>
                      </div>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold text-gray-900 font-inter">
                            Burnout Recovery Circle
                          </h4>
                          <p className="text-sm text-gray-600 font-inter">
                            Support for professionals experiencing burnout
                          </p>
                        </div>
                        <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-inter">
                          Join
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;